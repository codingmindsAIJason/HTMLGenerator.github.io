import openai
import json
import os
import io

from PIL import Image
from stability_sdk import client
import stability_sdk.interfaces.gooseai.generation.generation_pb2 as generation

openai.api_key = "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"
os.environ['STABILITY_HOST'] = 'grpc.stability.ai:443'
os.environ['STABILITY_KEY'] = 'sk-2LRhCKC1FUOwFSPto5yJtUhAhz6NvqcjaNzdbeZXuQ1x5I2P'

def get_sentences_and_prompts(model, topic, pattern, number):
  system_message = f"""
  Your job is to generate {number} sentences by filling out the parentheses in the pattern. \
  The information you generate should be following the topic. \
  For each sentence, you should also write a prompt for generating the corresponding AI images. \
  To write the prompt, you should follow the following guidelines:
  1 - Be specific and detailed about the image you want the AI to generate.
  2 - Use sensory language to describe textures, sounds, smells, and other sensory details.
  3 - Consider composition and perspective by providing guidelines on camera angles, framing, and object arrangement.
  4 - Set the mood and atmosphere by describing the desired emotional context of the image.
  5 - Incorporate storytelling elements to give the AI image a sense of narrative or drama.
  6 - Reference existing art or images as inspiration or guidance for the desired aesthetic. \
  You should output a JSON array of objects, where each object corresponds to a sentence and its prompt.\
  Each object should have its sentence with key "sentence" and its prompt with key "prompt"."""

  user_message = f"""
  The topic is {topic}. \
  The pattern is delimited by <>
  <{pattern}>
  """

  response = openai.ChatCompletion.create(
    model=model,
    messages=[
        {"role": "system", "content": system_message},
        {"role": "user", "content": user_message},
    ],
    temperature=0,
  )

  contents = response['choices'][0]['message']['content']
  return contents


def gen_slogan(model, topic, sentences):
  system_message = """Your job is to generate a slogan given a topic and some sentences. \
  The slogan should be based on the topic and the given sentences. The slogan itself should be one-sentence long."""

  user_message = f"""
  The topic is {topic}. \
  The pattern is delimited by <>
  <{" ".join(sentences)}>
  """

  response = openai.ChatCompletion.create(
    model=model,
    messages=[
        {"role": "system", "content": system_message},
        {"role": "user", "content": user_message},
    ],
    temperature=0,
  )

  slogan = response['choices'][0]['message']['content']
  return slogan



def gen_images(prompts, image_style):
  stability_api = client.StabilityInference(
      key=os.environ['STABILITY_KEY'],  # API Key reference.
      verbose=True,  # Print debug messages.
      engine= "stable-diffusion-xl-beta-v2-2-2",  # Set the engine to use for generation.
      # Available engines: stable-diffusion-v1 stable-diffusion-v1-5 stable-diffusion-512-v2-0 stable-diffusion-768-v2-0
      # stable-diffusion-512-v2-1 stable-diffusion-768-v2-1 stable-diffusion-xl-beta-v2-2-2 stable-inpainting-v1-0 stable-inpainting-512-v2-0
  )

  images = []

  for i, prompt in enumerate(prompts):
    answers = stability_api.generate(
      prompt=prompt,
      style_preset = image_style,
      seed=992446758,  # If a seed is provided, the resulting generated image will be deterministic.
      # What this means is that as long as all generation parameters remain the same, you can always recall the same image simply by generating it again.
      # Note: This isn't quite the case for CLIP Guided generations, which we tackle in the CLIP Guidance documentation.
      steps=30,  # Amount of inference steps performed on image generation. Defaults to 30.
      cfg_scale=8.0,  # Influences how strongly your generation is guided to match your prompt.
      # Setting this value higher increases the strength in which it tries to match your prompt.
      # Defaults to 7.0 if not specified.
      width=512,  # Generation width, defaults to 512 if not included.
      height=512,  # Generation height, defaults to 512 if not included.
      samples=1,  # Number of images to generate, defaults to 1 if not included.
      sampler=generation.SAMPLER_K_DPMPP_2M  # Choose which sampler we want to denoise our generation with.
      # Defaults to k_dpmpp_2m if not specified. Clip Guidance only supports ancestral samplers.
      # (Available Samplers: ddim, plms, k_euler, k_euler_ancestral, k_heun, k_dpm_2, k_dpm_2_ancestral, k_dpmpp_2s_ancestral, k_lms, k_dpmpp_2m, k_dpmpp_sde)
    )

    for resp in answers:
      for artifact in resp.artifacts:
        if artifact.finish_reason == generation.FILTER:
          print("Generation failed.")
        if artifact.type == generation.ARTIFACT_IMAGE:
          img = Image.open(io.BytesIO(artifact.binary))
          img.save(str(i)+".png")
          images.append(str(i)+".png")

  return images


def gen_background_image(slogan, image_style):
  stability_api = client.StabilityInference(
      key=os.environ['STABILITY_KEY'],  # API Key reference.
      verbose=True,  # Print debug messages.
      engine= "stable-diffusion-xl-beta-v2-2-2",  # Set the engine to use for generation.
      # Available engines: stable-diffusion-v1 stable-diffusion-v1-5 stable-diffusion-512-v2-0 stable-diffusion-768-v2-0
      # stable-diffusion-512-v2-1 stable-diffusion-768-v2-1 stable-diffusion-xl-beta-v2-2-2 stable-inpainting-v1-0 stable-inpainting-512-v2-0
  )



  answers = stability_api.generate(
    prompt=slogan,
    style_preset = image_style,
    seed=992446758,  # If a seed is provided, the resulting generated image will be deterministic.
    # What this means is that as long as all generation parameters remain the same, you can always recall the same image simply by generating it again.
    # Note: This isn't quite the case for CLIP Guided generations, which we tackle in the CLIP Guidance documentation.
    steps=30,  # Amount of inference steps performed on image generation. Defaults to 30.
    cfg_scale=8.0,  # Influences how strongly your generation is guided to match your prompt.
    # Setting this value higher increases the strength in which it tries to match your prompt.
    # Defaults to 7.0 if not specified.
    width=512,  # Generation width, defaults to 512 if not included.
    height=256,  # Generation height, defaults to 512 if not included.
    samples=1,  # Number of images to generate, defaults to 1 if not included.
    sampler=generation.SAMPLER_K_DPMPP_2M  # Choose which sampler we want to denoise our generation with.
    # Defaults to k_dpmpp_2m if not specified. Clip Guidance only supports ancestral samplers.
    # (Available Samplers: ddim, plms, k_euler, k_euler_ancestral, k_heun, k_dpm_2, k_dpm_2_ancestral, k_dpmpp_2s_ancestral, k_lms, k_dpmpp_2m, k_dpmpp_sde)
  )

  for resp in answers:
    for artifact in resp.artifacts:
      if artifact.finish_reason == generation.FILTER:
        print("Generation failed.")
      if artifact.type == generation.ARTIFACT_IMAGE:
        img = Image.open(io.BytesIO(artifact.binary))
        img.save("background.png")


  return "background.png"


def gen_html(model, topic, slogan, sentences, background_image, images, website_demand):
  system_message = """You will be provided with a topic, a slogan, a background image, a certain number of sentences and the same number of images. \
  Your job is to generate a HTML file based on the given information. \
  The header contains the topic only. \
  A container contains the slogan and the background image. \
  The background image is only for this container, not the whole webpage. \
  It should be transparent so that the user can read the slogan. \
  In addition, another container shows the sentences and their corresponding images."""
  system_message += website_demand

  user_message = f"""The topic is {topic}. The slogan is {slogan}. \
  The sentences are {str(sentences)}. \
  The source of the background image is {background_image}. \
  The source of the images are {str(images)}."""

  response = openai.ChatCompletion.create(
    model=model,
    messages=[
        {"role": "system", "content": system_message},
        {"role": "user", "content": user_message},
    ],
    temperature=0,
  )

  html = response['choices'][0]['message']['content']
  return html






def generate_website(model, topic, pattern, number, image_style, background_image_style, website_demand):
    print("generating sentences and prompts...")
    contents = get_sentences_and_prompts(model, topic, pattern, number)
    contents = json.loads(contents)
    sentences = []
    prompts = []
    for item in contents:
      sentences.append(item["sentence"])
      prompts.append(item["prompt"])

    print("generating slogan...")
    slogan = gen_slogan(model, topic, sentences)

    print("generating images...")
    images = gen_images(prompts, image_style)

    print("generating background images...")
    background_image = gen_background_image(slogan, background_image_style)

    print("generating html...")
    html_file = gen_html(model, topic, slogan, sentences, background_image, images, website_demand)
    
    with open("website.html", "w") as f:
        f.write(html_file)






# model = "gpt-3.5-turbo"
# topic = "American Singers"
# pattern = "(artist) perform (song) at (stadium)."
# number = 3
# image_style = "enhance"
# background_image_style = "anime"
# website_demand = "The background color of the whole website should be vivid."

# generate_website(model, topic, pattern, number, image_style, background_image_style, website_demand)







