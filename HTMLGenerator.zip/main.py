from ui import main_func

if __name__ == '__main__':
    main_func()