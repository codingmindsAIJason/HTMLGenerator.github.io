import tkinter as tk
from tkinter import ttk

import model

def main_func():
    def is_valid(char):
        return char.isdigit() and not char == "0"

    def on_widget_click(event, widget, placeholder_text):
        text = widget.get("1.0", "end-1c")
        if text == placeholder_text:
            widget.delete("1.0", "end-1c")
            widget.configure(fg="black")

    def on_widget_leave(event, widget, placeholder_text):
        text = widget.get("1.0", "end-1c")
        if text == "":
            widget.insert("1.0", placeholder_text)
            widget.configure(fg="grey")

    def on_key(event, widget):
        input_text = widget.get("1.0", "end-1c")
        if not is_valid(input_text):
            widget.delete("end-2c", "end-1c")
            window.bell()



    def generate():
        nonlocal topic, pattern, number, image_style, background_image_style, website_demand
        topic = topic_entry.get("1.0", "end-1c")
        pattern = pattern_entry.get("1.0", "end-1c")
        number = int(number_entry.get("1.0", "end-1c"))
        image_style = image_style_entry.get()
        background_image_style = background_image_style_entry.get()
        website_demand = website_demand_entry.get("1.0", "end-1c")
        window.destroy()

    def make_label(label_text):
        label = tk.Label(window, text=label_text)
        label.pack()

        return label

    def make_entry(placeholder_text, entry_width, entry_height, is_number=False):
        entry = tk.Text(window, width=entry_width, height=entry_height)
        entry.insert("1.0", placeholder_text)
        entry.configure(fg="grey")
        entry.bind("<FocusIn>", lambda event: on_widget_click(event, entry, placeholder_text))
        entry.bind("<FocusOut>", lambda event: on_widget_leave(event, entry, placeholder_text))
        if is_number:
            entry.bind("<KeyRelease>", lambda event: on_key(event, entry))

        entry.pack()

        return entry

    def make_combobox(lst):
        entry = ttk.Combobox(window, values=lst, state='readonly')
        entry.pack()

        return entry

    def make_button(button_text, button_command):
        button = tk.Button(window, text = button_text, command = button_command)
        button.pack()

        return button




    window = tk.Tk()
    window.title("HTML Generator")
    window.geometry('400x500')


    topic = ""
    pattern = ""
    number = ""
    image_style = ""
    background_image_style = ""
    website_demand = ""



    topic_label = make_label("Topic")
    topic_placeholder_text = "American Singers"
    topic_entry = make_entry(topic_placeholder_text, 40, 1)

    pattern_label = make_label("Pattern")
    pattern_placeholder_text = "(artist) perform (song) at (stadium)"
    pattern_entry = make_entry(pattern_placeholder_text, 40, 5)

    number_label = make_label("Number")
    number_placeholder_text = "3"
    number_entry = make_entry(number_placeholder_text, 40, 1, is_number=True)




    styles_list = ["enhance", "anime", "photographic", "digital-art", "comic-book", "fantasy-art", 
                    "line-art", "analog-film", "neon-punk", "isometric", "low-poly", "origami",
                    "modeling-compound", "cinematic", "3d-model", "pixel-art", "tile-texture"]

    image_style_label = make_label("Image Style")
    image_style_entry = make_combobox(styles_list)

    background_image_style_label = make_label("Background Image Style")
    background_image_style_entry = make_combobox(styles_list)

    website_demand_label = make_label("Website Demand")
    website_demand_placeholder_text = "The background color of the whole website should be vivid."
    website_demand_entry = make_entry(website_demand_placeholder_text, 40, 7)

    generate_button = make_button("Generate", generate)




    window.mainloop()
    # print("Topic:", topic)
    # print("Pattern:", pattern)
    # print("Number:", number)
    # print("Image Style:", image_style)
    # print("Background Image Style:", background_image_style)
    # print("Website Demand:", website_demand)


    ai_model = "gpt-3.5-turbo"
    model.generate_website(ai_model, topic, pattern, number, image_style, background_image_style, website_demand)





